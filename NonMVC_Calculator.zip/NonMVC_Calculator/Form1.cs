using System;
using System.Windows.Forms;

namespace NonMVC_Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double number1;
            double number2;

            bool validNumber1 = double.TryParse(txtNumber1.Text, out number1);
            bool validNumber2 = double.TryParse(txtNumber2.Text, out number2);

            if (validNumber1 && validNumber2)
            {
                double sum = number1 + number2;

                lblResult.Text = "Result: " + sum.ToString();
            }
            else
            {
                lblResult.Text = "Please enter valid numbers.";
            }
        }
    }
}